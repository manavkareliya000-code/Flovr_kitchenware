import { Link } from "react-router-dom";
import {
  ChefHat,
  Home,
  Package,
  Sparkles,
  Bath,
  ArrowUpRight,
} from "lucide-react";

const categories = [
  {
    name: "Kitchenware",
    description: "Cook & dine beautifully",
    path: "/Kitchenware",
    image:
      "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcR-UUFvf18FsHCiuqU-e5oA4sfLqPNAqNDRaack1NHjcjzegX4r",

    icon: ChefHat,
  },
  {
    name: "Household",
    description: "Essentials for everyday living",
    path: "/Household",
    image:
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1000&q=85",

    icon: Home,
  },
  {
    name: "Storage",
    description: "Organize your space",
    path: "/Storage",
    image:
      "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcSBSmzv2z6UURt6ktaB9OAkPEUBRSWDV7xTdLylpZhtHg7nk5qD234rsizfgqF-fLHUkHHFGLaAu7QKJicyd5HhK9Csxs6j0c68-m2864q9",

    icon: Package,
  },
  {
    name: "Cleaning",
    description: "Keep your home fresh",
    path: "/Cleaning",
    image:
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=1000&q=85",

    icon: Sparkles,
  },
  {
    name: "Bathroom",
    description: "Simple & smart essentials",
    path: "/Bathroom",
    image:
      "https://novatech.ind.in/wp-content/uploads/2025/08/Corner-Shelf-Organizer.webp",
    icon: Bath,
  },
];

function CategorySection() {
  return (
    <section className="bg-[#ffff] px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-7xl">
        {/* Heading */}
        <div className="mb-10 text-center sm:mb-14">
          <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-[#A86643]">
            Explore FLOVR
          </p>

          <h2 className="text-3xl font-semibold tracking-tight text-[#4A3428] sm:text-4xl">
            Shop by Category
          </h2>

          <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-[#75675D] sm:text-base">
            Discover thoughtfully selected essentials made for a beautiful,
            organized and comfortable home.
          </p>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap justify-center gap-7 overflow-x-auto px-2 pb-4 sm:overflow-visible sm:px-0 lg:gap-12">
          {categories.map((category) => {
            const Icon = category.icon;

            return (
              <Link
                key={category.name}
                to={category.path}
                className="group flex flex-col items-center text-center"
              >
                {/* Circle */}
                <div className="relative">
                  <div className="md:h-36 md:w-36 h-30 w-30 overflow-hidden rounded-full border-[6px] border-[#FFFDFC] bg-[#EDE3D7] shadow-[0_8px_25px_rgba(74,52,40,0.10)] transition-all duration-500 group-hover:-translate-y-2 group-hover:border-[#A86643] group-hover:shadow-[0_18px_35px_rgba(74,52,40,0.18)]  lg:h-44 lg:w-44">
                    <img
                      src={category.image}
                      alt={category.name}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                  </div>

                  {/* Floating icon */}
                  <div className="absolute bottom-1 right-1 flex h-9 w-9 items-center justify-center rounded-full border-2 border-[#FFFDFC] bg-[#4A3428] text-white shadow-md transition-all duration-300 group-hover:scale-110 group-hover:bg-[#A86643]">
                    <Icon size={16} strokeWidth={1.8} />
                  </div>

                  {/* Arrow */}
                  <div className="absolute left-1 top-1 flex h-8 w-8 -translate-x-1 -translate-y-1 items-center justify-center rounded-full border-2  bg-[#FFFDFC] text-[#4A3428] opacity-0 shadow-md transition-all duration-300 group-hover:translate-x-0 group-hover:translate-y-0 group-hover:opacity-100 group-hover:bg-[#A86643] group-hover:text-white group-border-[#FFFDFC]">
                    <ArrowUpRight size={15} />
                  </div>
                </div>

                {/* Category name */}
                <h3 className="mt-5 text-base font-semibold text-[#4A3428] transition-colors duration-300 group-hover:text-[#A86643] sm:text-lg">
                  {category.name}
                </h3>

                {/* Description */}
                <p className="mt-1 max-w-[100px] text-xs leading-5 text-[#75675D] sm:text-sm">
                  {category.description}
                </p>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default CategorySection;
