import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import { useWishlist } from "../../context/WishlistContext";
import { useToast } from "../../context/ToastContext";

import {
  ArrowLeft,
  ArrowRight,
  Heart,
  Minus,
  Plus,
  ShoppingBag,
  Truck,
  RotateCcw,
  ShieldCheck,
  Check,
  ChevronRight,
  Star,
  Send,
  Trash2,
  MessageCircle,
  Pencil,
  X,
} from "lucide-react";

import products from "../../data/products";
import ProductCard from "../../components/ProductCard/ProductCard";

const REVIEW_KEY = "flovr-product-reviews";
const LOGIN_KEY = "flovr-logged-in";
const USER_KEY = "flovr-user";

function ProductDetails() {
  const navigate = useNavigate();
  const { id } = useParams();

  const product = products.find((item) => item.id === Number(id));

  const { addToCart } = useCart();
  const { showToast } = useToast();
  const { toggleWishlist, isInWishlist } = useWishlist();

  // =========================================================
  // IMAGE
  // =========================================================

  const [selectedImage, setSelectedImage] = useState(0);

  // =========================================================
  // QUANTITY
  // =========================================================

  const [quantity, setQuantity] = useState(1);

  // =========================================================
  // PRODUCT TABS
  // =========================================================

  const [activeTab, setActiveTab] = useState("description");

  // =========================================================
  // REVIEWS
  // =========================================================

  const [reviews, setReviews] = useState([]);

  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");
  const [hoverRating, setHoverRating] = useState(0);

  const [showReviewForm, setShowReviewForm] = useState(false);

  // Stores review ID when editing
  const [editingReviewId, setEditingReviewId] = useState(null);

  // =========================================================
  // LOAD REVIEWS
  // =========================================================

  useEffect(() => {
    try {
      const savedReviews = JSON.parse(localStorage.getItem(REVIEW_KEY) || "[]");

      setReviews(Array.isArray(savedReviews) ? savedReviews : []);
    } catch (error) {
      console.error("Failed to load reviews:", error);
      setReviews([]);
    }
  }, [id]);

  // =========================================================
  // RESET WHEN PRODUCT CHANGES
  // =========================================================

  useEffect(() => {
    setSelectedImage(0);
    setQuantity(1);
    setActiveTab("description");

    setShowReviewForm(false);
    setEditingReviewId(null);

    setReviewComment("");
    setReviewRating(5);
    setHoverRating(0);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }, [id]);

  // =========================================================
  // PRODUCT NOT FOUND
  // =========================================================

  if (!product) {
    return (
      <div className="min-h-[70vh] bg-[#F7F1E8] px-5 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-[#EFE3D4]">
            <ShoppingBag size={32} className="text-[#4A3428]" />
          </div>

          <h1 className="text-3xl font-bold text-[#4A3428]">
            Product Not Found
          </h1>

          <p className="mt-3 text-[#75675D]">
            Sorry, the product you're looking for doesn't exist.
          </p>

          <Link
            to="/shop"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-[#4A3428] px-6 py-3 text-sm font-medium text-white transition hover:bg-[#A86643]"
          >
            <ArrowLeft size={17} />
            Back to Shop
          </Link>
        </div>
      </div>
    );
  }

  // =========================================================
  // PRODUCT IMAGES
  // =========================================================

  const images =
    product.images && product.images.length > 0
      ? product.images
      : [product.image];

  // =========================================================
  // RELATED PRODUCTS
  // =========================================================

  const relatedProducts = products
    .filter(
      (item) => item.category === product.category && item.id !== product.id,
    )
    .slice(0, 4);

  // =========================================================
  // CURRENT PRODUCT REVIEWS
  // =========================================================

  const productReviews = useMemo(() => {
    return reviews
      .filter((review) => Number(review.productId) === Number(product.id))
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [reviews, product.id]);

  // =========================================================
  // CALCULATED RATING
  // =========================================================

  const calculatedRating = useMemo(() => {
    if (productReviews.length === 0) {
      return Number(product.rating || 0);
    }

    const total = productReviews.reduce(
      (sum, review) => sum + Number(review.rating || 0),
      0,
    );

    return total / productReviews.length;
  }, [productReviews, product.rating]);

  // =========================================================
  // REVIEW COUNT
  // =========================================================

  const reviewCount =
    productReviews.length > 0
      ? productReviews.length
      : Number(product.reviews || 0);

  // =========================================================
  // RATING DISTRIBUTION
  // =========================================================

  const ratingDistribution = useMemo(() => {
    const distribution = {
      5: 0,
      4: 0,
      3: 0,
      2: 0,
      1: 0,
    };

    productReviews.forEach((review) => {
      const rating = Number(review.rating);

      if (distribution[rating] !== undefined) {
        distribution[rating] += 1;
      }
    });

    return distribution;
  }, [productReviews]);

  // =========================================================
  // CURRENT USER
  // =========================================================

  const currentUser = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY) || "null");
    } catch {
      return null;
    }
  }, []);

  const currentUserName =
    `${currentUser?.firstName || ""} ${currentUser?.lastName || ""}`.trim() ||
    currentUser?.name ||
    currentUser?.email ||
    "FLOVR Customer";

  // =========================================================
  // QUANTITY
  // =========================================================

  const decreaseQuantity = () => {
    setQuantity((prev) => Math.max(1, prev - 1));
  };

  const increaseQuantity = () => {
    setQuantity((prev) => Math.min(product.stock, prev + 1));
  };

  // =========================================================
  // IMAGE CONTROLS
  // =========================================================

  const previousImage = () => {
    setSelectedImage((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const nextImage = () => {
    setSelectedImage((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  // =========================================================
  // ADD TO CART
  // =========================================================

  const handleAddToCart = () => {
    addToCart(product, quantity);

    // This is the ONLY place using the cart toast.
    showToast(`${quantity} × ${product.name}`);
  };

  // =========================================================
  // BUY NOW
  // =========================================================

  const handleBuyNow = () => {
    addToCart(product, quantity);
    navigate("/cart");
  };

  // =========================================================
  // OPEN REVIEW FORM
  // =========================================================

  const handleWriteReview = () => {
    const loggedIn = localStorage.getItem(LOGIN_KEY) === "true";

    if (!loggedIn) {
      navigate("/login");
      return;
    }

    // New review mode
    setEditingReviewId(null);
    setReviewRating(5);
    setReviewComment("");
    setHoverRating(0);

    setShowReviewForm(true);

    setTimeout(() => {
      document.getElementById("write-review")?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }, 100);
  };

  // =========================================================
  // EDIT REVIEW
  // =========================================================

  const handleEditReview = (review) => {
    setEditingReviewId(review.id);

    setReviewRating(Number(review.rating) || 5);
    setReviewComment(review.comment || "");
    setHoverRating(0);

    setShowReviewForm(true);

    setTimeout(() => {
      document.getElementById("write-review")?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }, 100);
  };

  // =========================================================
  // CANCEL REVIEW FORM / EDIT
  // =========================================================

  const handleCancelReview = () => {
    setEditingReviewId(null);
    setReviewRating(5);
    setReviewComment("");
    setHoverRating(0);
    setShowReviewForm(false);
  };

  // =========================================================
  // SUBMIT / UPDATE REVIEW
  // =========================================================

  const handleSubmitReview = (event) => {
    event.preventDefault();

    const isLoggedIn = localStorage.getItem(LOGIN_KEY) === "true";

    if (!isLoggedIn) {
      navigate("/login");
      return;
    }

    if (!reviewComment.trim()) {
      return;
    }

    let savedUser = {};

    try {
      savedUser = JSON.parse(localStorage.getItem(USER_KEY) || "{}");
    } catch {
      savedUser = {};
    }

    const userName =
      `${savedUser?.firstName || ""} ${savedUser?.lastName || ""}`.trim() ||
      savedUser?.name ||
      savedUser?.email ||
      "FLOVR Customer";

    let allReviews = [];

    try {
      allReviews = JSON.parse(localStorage.getItem(REVIEW_KEY) || "[]");

      if (!Array.isArray(allReviews)) {
        allReviews = [];
      }
    } catch {
      allReviews = [];
    }

    // =======================================================
    // UPDATE EXISTING REVIEW
    // =======================================================

    if (editingReviewId !== null) {
      const reviewIndex = allReviews.findIndex(
        (review) =>
          review.id === editingReviewId &&
          Number(review.productId) === Number(product.id) &&
          review.userName === userName,
      );

      if (reviewIndex === -1) {
        return;
      }

      allReviews[reviewIndex] = {
        ...allReviews[reviewIndex],
        rating: Number(reviewRating),
        comment: reviewComment.trim(),
        date: new Date().toISOString(),
      };

      localStorage.setItem(REVIEW_KEY, JSON.stringify(allReviews));

      setReviews(allReviews);

      // Reset form
      setEditingReviewId(null);
      setReviewRating(5);
      setReviewComment("");
      setHoverRating(0);
      setShowReviewForm(false);

      return;
    }

    // =======================================================
    // ADD NEW REVIEW
    // =======================================================

    const newReview = {
      id: Date.now(),
      productId: product.id,
      userName,
      rating: Number(reviewRating),
      comment: reviewComment.trim(),
      date: new Date().toISOString(),
    };

    const updatedReviews = [...allReviews, newReview];

    localStorage.setItem(REVIEW_KEY, JSON.stringify(updatedReviews));

    setReviews(updatedReviews);

    // Reset form
    setReviewRating(5);
    setReviewComment("");
    setHoverRating(0);
    setEditingReviewId(null);
    setShowReviewForm(false);
  };

  // =========================================================
  // DELETE REVIEW
  // =========================================================

  const handleDeleteReview = (reviewId) => {
    let user = null;

    try {
      user = JSON.parse(localStorage.getItem(USER_KEY) || "null");
    } catch {
      user = null;
    }

    const currentName =
      `${user?.firstName || ""} ${user?.lastName || ""}`.trim() ||
      user?.name ||
      user?.email ||
      "FLOVR Customer";

    const reviewToDelete = productReviews.find(
      (review) => review.id === reviewId,
    );

    if (!reviewToDelete) {
      return;
    }

    // Only owner can delete
    if (reviewToDelete.userName !== currentName) {
      return;
    }

    const updatedReviews = reviews.filter((review) => review.id !== reviewId);

    localStorage.setItem(REVIEW_KEY, JSON.stringify(updatedReviews));

    setReviews(updatedReviews);

    // If currently editing deleted review
    if (editingReviewId === reviewId) {
      handleCancelReview();
    }
  };

  // =========================================================
  // REVIEW DATE
  // =========================================================

  const formatReviewDate = (date) => {
    const parsedDate = new Date(date);

    if (Number.isNaN(parsedDate.getTime())) {
      return "";
    }

    return parsedDate.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  // =========================================================
  // MAIN UI
  // =========================================================

  return (
    <div className="bg-[#F7F1E8] text-[#4A3428]">
      {/* =====================================================
          BREADCRUMB
      ====================================================== */}

      <div className="border-b border-[#D9CBBE] bg-[#FFFDFC]">
        <div className="mx-auto max-w-7xl px-5 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 overflow-x-auto whitespace-nowrap text-sm">
            <Link
              to="/"
              className="text-[#75675D] transition hover:text-[#A86643]"
            >
              Home
            </Link>

            <ChevronRight size={15} className="shrink-0 text-[#D6AE8C]" />

            <Link
              to="/shop"
              className="text-[#75675D] transition hover:text-[#A86643]"
            >
              Shop
            </Link>

            <ChevronRight size={15} className="shrink-0 text-[#D6AE8C]" />

            <Link
              to={`/${product.category.toLowerCase()}`}
              className="text-[#75675D] transition hover:text-[#A86643]"
            >
              {product.category}
            </Link>

            <ChevronRight size={15} className="shrink-0 text-[#D6AE8C]" />

            <span className="max-w-[220px] truncate font-medium text-[#4A3428]">
              {product.name}
            </span>
          </div>
        </div>
      </div>

      {/* =====================================================
          BACK BUTTON
      ====================================================== */}

      <div>
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="mx-8 mt-5 inline-flex items-center gap-2 rounded-full border border-[#4A3428] bg-[#FFFDFC] px-2.5 py-1.5 text-sm font-semibold text-[#4A3428] transition hover:bg-[#4A3428] hover:text-[#FFFDFC]"
        >
          <ArrowLeft size={18} />
          Back
        </button>
      </div>

      {/* =====================================================
          PRODUCT MAIN SECTION
      ====================================================== */}

      <section className="mx-auto max-w-7xl px-5 py-8 sm:px-6 sm:py-12 lg:px-8 lg:pb-16 lg:pt-7">
        <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
          {/* IMAGE GALLERY */}

          <div>
            <div className="relative overflow-hidden rounded-3xl border border-[#D9CBBE] bg-[#EDE3D7]">
              <div className="aspect-square overflow-hidden">
                <img
                  src={images[selectedImage]}
                  alt={product.name}
                  className="h-full w-full object-cover transition duration-700 hover:scale-105"
                />
              </div>

              {images.length > 1 && (
                <button
                  type="button"
                  onClick={previousImage}
                  className="absolute left-4 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-[#4A3428] shadow-md backdrop-blur transition hover:bg-[#4A3428] hover:text-white"
                  aria-label="Previous image"
                >
                  <ArrowLeft size={18} />
                </button>
              )}

              {images.length > 1 && (
                <button
                  type="button"
                  onClick={nextImage}
                  className="absolute right-4 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-[#4A3428] shadow-md backdrop-blur transition hover:bg-[#4A3428] hover:text-white"
                  aria-label="Next image"
                >
                  <ArrowRight size={18} />
                </button>
              )}
            </div>

            {/* THUMBNAILS */}

            <div className="mt-4 grid grid-cols-4 gap-3">
              {images.map((image, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => setSelectedImage(index)}
                  className={`aspect-square overflow-hidden rounded-xl border-2 bg-[#EDE3D7] transition ${
                    selectedImage === index
                      ? "border-[#4A3428]"
                      : "border-[#D9CBBE] hover:border-[#A86643]"
                  }`}
                >
                  <img
                    src={image}
                    alt={`${product.name} ${index + 1}`}
                    className="h-full w-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* PRODUCT INFORMATION */}

          <div className="flex flex-col">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[#A86643]">
                {product.category}
              </p>

              <div className="flex gap-2">
                {product.isNew && (
                  <span className="rounded-full bg-[#4A3428] px-4 py-1.5 text-xs font-semibold text-white shadow-sm">
                    New Arrival
                  </span>
                )}

                {product.isBestSeller && (
                  <span className="rounded-full bg-[#A86643] px-4 py-1.5 text-xs font-semibold text-white shadow-sm">
                    Best Seller
                  </span>
                )}
              </div>
            </div>

            <h1 className="mt-3 text-3xl font-bold leading-tight text-[#4A3428] sm:text-4xl lg:text-[42px]">
              {product.name}
            </h1>

            <p className="mt-4 text-base leading-7 text-[#75675D]">
              {product.shortDescription}
            </p>

            {/* DYNAMIC RATING */}

            <button
              type="button"
              onClick={() => {
                setActiveTab("reviews");

                setTimeout(() => {
                  document.getElementById("product-reviews")?.scrollIntoView({
                    behavior: "smooth",
                  });
                }, 100);
              }}
              className="mt-5 flex w-fit flex-wrap items-center gap-3"
            >
              <div className="flex items-center gap-1 rounded-full bg-[#EFE3D4] px-3 py-1.5">
                <Star
                  size={16}
                  fill="currentColor"
                  className="text-[#A86643]"
                />

                <span className="text-sm font-semibold text-[#4A3428]">
                  {calculatedRating.toFixed(1)}
                </span>
              </div>

              <span className="text-sm text-[#75675D] underline-offset-4 hover:underline">
                {reviewCount} customer reviews
              </span>
            </button>

            <div className="my-6 h-px bg-[#D9CBBE]" />

            {/* PRICE */}

            <div className="flex flex-wrap items-center gap-3">
              <span className="text-3xl font-bold text-[#4A3428]">
                ₹{product.price.toLocaleString("en-IN")}
              </span>

              {product.originalPrice && (
                <span className="text-lg text-[#75675D] line-through">
                  ₹{product.originalPrice.toLocaleString("en-IN")}
                </span>
              )}

              {product.discount && (
                <span className="mx-1 rounded-full border border-green-600 bg-amber-50 px-2 py-1 text-sm font-bold text-green-600">
                  Save {product.discount}%
                </span>
              )}
            </div>

            {/* STOCK */}

            <div className="mt-4 flex items-center gap-2">
              {product.stock > 0 ? (
                <>
                  <span className="h-2.5 w-2.5 rounded-full bg-green-600" />

                  <span className="text-sm font-medium text-green-700">
                    In Stock
                  </span>

                  <span className="text-sm text-[#75675D]">
                    • {product.stock} available
                  </span>
                </>
              ) : (
                <>
                  <span className="h-2.5 w-2.5 rounded-full bg-red-500" />

                  <span className="text-sm font-medium text-red-600">
                    Out of Stock
                  </span>
                </>
              )}
            </div>

            <p className="mt-2 text-xs text-[#75675D]">SKU: {product.sku}</p>

            {/* QUANTITY + WISHLIST */}

            <div className="mt-7 flex flex-wrap gap-7">
              <div className="flex h-12 items-center rounded-xl border border-[#D9CBBE] bg-[#FFFDFC]">
                <button
                  type="button"
                  onClick={decreaseQuantity}
                  disabled={quantity <= 1}
                  className="flex h-full w-11 items-center justify-center text-[#4A3428] transition hover:text-[#A86643] disabled:cursor-not-allowed disabled:opacity-40"
                >
                  <Minus size={17} />
                </button>

                <span className="flex w-10 justify-center text-sm font-semibold">
                  {quantity}
                </span>

                <button
                  type="button"
                  onClick={increaseQuantity}
                  disabled={quantity >= product.stock}
                  className="flex h-full w-11 items-center justify-center text-[#4A3428] transition hover:text-[#A86643] disabled:cursor-not-allowed disabled:opacity-40"
                >
                  <Plus size={17} />
                </button>
              </div>

              <button
                type="button"
                onClick={() => toggleWishlist(product)}
                className={`flex h-12 w-12 items-center justify-center rounded-xl border transition ${
                  isInWishlist(product.id)
                    ? "border-[#A86643] bg-[#A86643] text-white"
                    : "border-[#D9CBBE] bg-[#FFFDFC] text-[#4A3428] hover:border-[#A86643] hover:text-[#A86643]"
                }`}
                aria-label="Add to wishlist"
              >
                <Heart
                  size={20}
                  fill={isInWishlist(product.id) ? "currentColor" : "none"}
                />
              </button>
            </div>

            {/* ACTION BUTTONS */}

            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={handleAddToCart}
                disabled={product.stock <= 0}
                className="flex h-13 items-center justify-center gap-2 rounded-xl bg-[#4A3428] px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-[#A86643] disabled:cursor-not-allowed disabled:opacity-50"
              >
                <ShoppingBag size={18} />
                Add to Cart
              </button>

              <button
                type="button"
                onClick={handleBuyNow}
                disabled={product.stock <= 0}
                className="flex h-13 items-center justify-center gap-2 rounded-xl border-2 border-[#4A3428] bg-transparent px-6 py-3.5 text-sm font-semibold text-[#4A3428] transition hover:bg-[#4A3428] hover:text-white disabled:cursor-not-allowed disabled:opacity-50"
              >
                Buy Now
                <ArrowRight size={18} />
              </button>
            </div>

            {/* DELIVERY */}

            <div className="mt-7 rounded-2xl border border-[#D9CBBE] bg-[#FFFDFC] p-5">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#EFE3D4] text-[#4A3428]">
                  <Truck size={19} />
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-[#4A3428]">
                    Delivery Information
                  </h3>

                  <p className="mt-1 text-sm leading-6 text-[#75675D]">
                    {product.delivery}
                  </p>
                </div>
              </div>
            </div>

            {/* TRUST FEATURES */}

            <div className="mt-5 grid grid-cols-3 gap-2 sm:gap-4">
              <TrustFeature icon={Truck} text="Fast Delivery" />

              <TrustFeature icon={ShieldCheck} text="Quality Assured" />

              <TrustFeature icon={RotateCcw} text="Easy Returns" />
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          PRODUCT INFORMATION
      ====================================================== */}

      <section className="border-y border-[#D9CBBE] bg-[#FFFDFC]">
        <div className="mx-auto max-w-7xl px-5 py-12 sm:px-6 lg:px-8 lg:py-16">
          {/* TABS */}

          <div className="flex overflow-x-auto border-b border-[#D9CBBE]">
            <ProductTab
              active={activeTab === "description"}
              onClick={() => setActiveTab("description")}
            >
              Description
            </ProductTab>

            <ProductTab
              active={activeTab === "features"}
              onClick={() => setActiveTab("features")}
            >
              Features
            </ProductTab>

            <ProductTab
              active={activeTab === "specifications"}
              onClick={() => setActiveTab("specifications")}
            >
              Specifications
            </ProductTab>

            <ProductTab
              active={activeTab === "reviews"}
              onClick={() => setActiveTab("reviews")}
            >
              Reviews
              <span className="ml-1.5 rounded-full bg-[#F0E5DA] px-2 py-0.5 text-[10px]">
                {reviewCount}
              </span>
            </ProductTab>
          </div>

          {/* TAB CONTENT */}

          <div className="pt-8">
            {/* DESCRIPTION */}

            {activeTab === "description" && (
              <div className="max-w-4xl">
                <h2 className="text-2xl font-bold text-[#4A3428]">
                  About this product
                </h2>

                <p className="mt-4 text-base leading-8 text-[#75675D]">
                  {product.description}
                </p>
              </div>
            )}

            {/* FEATURES */}

            {activeTab === "features" && (
              <div className="max-w-3xl">
                <h2 className="text-2xl font-bold text-[#4A3428]">
                  Product Features
                </h2>

                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  {product.features?.map((feature, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-3 rounded-xl bg-[#F7F1E8] p-4"
                    >
                      <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#D6AE8C]">
                        <Check size={14} className="text-[#4A3428]" />
                      </div>

                      <span className="text-sm leading-6 text-[#4A3428]">
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SPECIFICATIONS */}

            {activeTab === "specifications" && (
              <div className="max-w-3xl">
                <h2 className="text-2xl font-bold text-[#4A3428]">
                  Product Specifications
                </h2>

                <div className="mt-6 overflow-hidden rounded-2xl border border-[#D9CBBE]">
                  {product.specifications &&
                    Object.entries(product.specifications).map(
                      ([key, value], index) => (
                        <div
                          key={key}
                          className={`grid grid-cols-2 ${
                            index !==
                            Object.entries(product.specifications).length - 1
                              ? "border-b border-[#D9CBBE]"
                              : ""
                          }`}
                        >
                          <div className="bg-[#F7F1E8] px-4 py-4 text-sm font-semibold text-[#4A3428] sm:px-6">
                            {key}
                          </div>

                          <div className="bg-[#FFFDFC] px-4 py-4 text-sm text-[#75675D] sm:px-6">
                            {value}
                          </div>
                        </div>
                      ),
                    )}
                </div>
              </div>
            )}

            {/* =================================================
                REVIEWS
            ================================================== */}

            {activeTab === "reviews" && (
              <div id="product-reviews" className="scroll-mt-24">
                <div className="grid gap-8 lg:grid-cols-[300px_1fr]">
                  {/* REVIEW SUMMARY */}

                  <div>
                    <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[#A86643]">
                      Customer Feedback
                    </p>

                    <h2 className="mt-2 text-2xl font-bold text-[#4A3428]">
                      Customer Reviews
                    </h2>

                    <div className="mt-6 rounded-3xl border border-[#E1D5CA] bg-[#F7F1E8] p-6">
                      <div className="text-center">
                        <div className="text-5xl font-bold text-[#4A3428]">
                          {calculatedRating.toFixed(1)}
                        </div>

                        <div className="mt-2 flex justify-center gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              size={18}
                              fill={
                                star <= Math.round(calculatedRating)
                                  ? "currentColor"
                                  : "none"
                              }
                              className="text-[#A86643]"
                            />
                          ))}
                        </div>

                        <p className="mt-2 text-xs text-[#81736A]">
                          Based on {reviewCount} review
                          {reviewCount !== 1 ? "s" : ""}
                        </p>
                      </div>

                      {/* RATING BARS */}

                      {productReviews.length > 0 && (
                        <div className="mt-7 space-y-2.5">
                          {[5, 4, 3, 2, 1].map((rating) => {
                            const count = ratingDistribution[rating];

                            const percentage =
                              productReviews.length > 0
                                ? (count / productReviews.length) * 100
                                : 0;

                            return (
                              <div
                                key={rating}
                                className="flex items-center gap-2"
                              >
                                <span className="w-5 text-xs font-medium text-[#75675D]">
                                  {rating}
                                </span>

                                <Star
                                  size={12}
                                  fill="currentColor"
                                  className="text-[#A86643]"
                                />

                                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#DCCFC3]">
                                  <div
                                    className="h-full rounded-full bg-[#A86643]"
                                    style={{
                                      width: `${percentage}%`,
                                    }}
                                  />
                                </div>

                                <span className="w-5 text-right text-[11px] text-[#8B7D73]">
                                  {count}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      <button
                        type="button"
                        onClick={handleWriteReview}
                        className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-[#4A3428] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#A86643]"
                      >
                        <MessageCircle size={17} />
                        Write a Review
                      </button>
                    </div>
                  </div>

                  {/* REVIEW LIST */}

                  <div>
                    {/* =================================================
                        WRITE / EDIT REVIEW FORM
                    ================================================== */}

                    {showReviewForm && (
                      <div
                        id="write-review"
                        className="mb-6 scroll-mt-24 rounded-3xl border border-[#D9CBBE] bg-[#F7F1E8] p-5 sm:p-6"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <div className="flex items-center gap-2">
                              {editingReviewId !== null && (
                                <Pencil size={17} className="text-[#A86643]" />
                              )}

                              <h3 className="text-lg font-semibold text-[#4A3428]">
                                {editingReviewId !== null
                                  ? "Edit your review"
                                  : "Write your review"}
                              </h3>
                            </div>

                            <p className="mt-1 text-xs text-[#81736A]">
                              {editingReviewId !== null
                                ? "Update your rating or review."
                                : "Share your experience with this product."}
                            </p>
                          </div>

                          <button
                            type="button"
                            onClick={handleCancelReview}
                            className="rounded-full p-2 text-[#75675D] transition hover:bg-white hover:text-[#4A3428]"
                            title="Close"
                          >
                            <X size={18} />
                          </button>
                        </div>

                        <form onSubmit={handleSubmitReview} className="mt-6">
                          {/* USER */}

                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#A86643] text-sm font-bold text-white">
                              {currentUserName
                                .split(" ")
                                .filter(Boolean)
                                .slice(0, 2)
                                .map((word) => word[0])
                                .join("")
                                .toUpperCase()}
                            </div>

                            <div>
                              <p className="text-sm font-semibold text-[#4A3428]">
                                {currentUserName}
                              </p>

                              <p className="text-xs text-[#83756C]">
                                Your review will be public.
                              </p>
                            </div>
                          </div>

                          {/* STAR INPUT */}

                          <div className="mt-6">
                            <p className="mb-2 text-xs font-semibold text-[#5F5148]">
                              Your Rating
                            </p>

                            <div className="flex items-center gap-1">
                              {[1, 2, 3, 4, 5].map((star) => {
                                const active =
                                  star <= (hoverRating || reviewRating);

                                return (
                                  <button
                                    key={star}
                                    type="button"
                                    onMouseEnter={() => setHoverRating(star)}
                                    onMouseLeave={() => setHoverRating(0)}
                                    onClick={() => setReviewRating(star)}
                                    className="rounded-md p-1 transition hover:bg-white"
                                    aria-label={`${star} star`}
                                  >
                                    <Star
                                      size={25}
                                      fill={active ? "currentColor" : "none"}
                                      className={
                                        active
                                          ? "text-[#A86643]"
                                          : "text-[#CBBDB1]"
                                      }
                                    />
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* COMMENT */}

                          <div className="mt-5">
                            <label className="mb-2 block text-xs font-semibold text-[#5F5148]">
                              Your Review
                            </label>

                            <textarea
                              value={reviewComment}
                              onChange={(e) => setReviewComment(e.target.value)}
                              rows={5}
                              maxLength={500}
                              placeholder="Tell other customers what you think about this product..."
                              className="w-full resize-none rounded-xl border border-[#D8CBC0] bg-white px-4 py-3 text-sm text-[#4A3428] outline-none transition placeholder:text-[#B0A198] focus:border-[#A86643] focus:ring-2 focus:ring-[#A86643]/10"
                            />

                            <div className="mt-1 text-right text-[11px] text-[#94867C]">
                              {reviewComment.length}/500
                            </div>
                          </div>

                          {/* SUBMIT */}

                          <button
                            type="submit"
                            disabled={!reviewComment.trim()}
                            className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#4A3428] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#A86643] disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            {editingReviewId !== null ? (
                              <>
                                <Check size={15} />
                                Update Review
                              </>
                            ) : (
                              <>
                                <Send size={15} />
                                Submit Review
                              </>
                            )}
                          </button>
                        </form>
                      </div>
                    )}

                    {/* REVIEW HEADER */}

                    <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
                      <div>
                        <h3 className="text-lg font-semibold text-[#4A3428]">
                          What customers say
                        </h3>

                        <p className="mt-1 text-xs text-[#83756C]">
                          Reviews from FLOVR customers.
                        </p>
                      </div>

                      {productReviews.length > 0 && (
                        <span className="text-xs font-medium text-[#8A7B71]">
                          {productReviews.length} customer review
                          {productReviews.length !== 1 ? "s" : ""}
                        </span>
                      )}
                    </div>

                    {/* EMPTY */}

                    {productReviews.length === 0 ? (
                      <div className="rounded-2xl border border-dashed border-[#D8CBC0] bg-[#FCF9F5] p-10 text-center">
                        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#F0E5DA] text-[#A86643]">
                          <MessageCircle size={23} />
                        </div>

                        <h3 className="mt-4 font-semibold text-[#4A3428]">
                          No customer reviews yet
                        </h3>

                        <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#81736A]">
                          Be the first customer to share your experience with
                          this product.
                        </p>

                        <button
                          type="button"
                          onClick={handleWriteReview}
                          className="mt-5 rounded-full bg-[#4A3428] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#A86643]"
                        >
                          Write the First Review
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {productReviews.map((review) => {
                          const isOwnReview =
                            review.userName === currentUserName;

                          return (
                            <div
                              key={review.id}
                              className="rounded-2xl border border-[#E2D6CA] bg-white p-5"
                            >
                              <div className="flex items-start justify-between gap-4">
                                <div className="flex items-center gap-3">
                                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#F0E5DA] text-xs font-bold text-[#A86643]">
                                    {review.userName
                                      .split(" ")
                                      .filter(Boolean)
                                      .slice(0, 2)
                                      .map((word) => word[0])
                                      .join("")
                                      .toUpperCase()}
                                  </div>

                                  <div>
                                    <div className="flex flex-wrap items-center gap-2">
                                      <h4 className="text-sm font-semibold text-[#4A3428]">
                                        {review.userName}
                                      </h4>

                                      {isOwnReview && (
                                        <span className="rounded-full bg-[#F3E9DF] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-[#A86643]">
                                          You
                                        </span>
                                      )}
                                    </div>

                                    <p className="mt-0.5 text-[11px] text-[#94867C]">
                                      {formatReviewDate(review.date)}
                                    </p>
                                  </div>
                                </div>

                                {/* EDIT + DELETE */}

                                {isOwnReview && (
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => handleEditReview(review)}
                                      className="rounded-lg p-2 text-[#A86643] transition hover:bg-[#F3E9DF]"
                                      title="Edit review"
                                    >
                                      <Pencil size={16} />
                                    </button>

                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleDeleteReview(review.id)
                                      }
                                      className="rounded-lg p-2 text-[#B36A61] transition hover:bg-[#FCEDEC]"
                                      title="Delete review"
                                    >
                                      <Trash2 size={16} />
                                    </button>
                                  </div>
                                )}
                              </div>

                              {/* REVIEW STARS */}

                              <div className="mt-4 flex gap-1">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <Star
                                    key={star}
                                    size={15}
                                    fill={
                                      star <= Number(review.rating)
                                        ? "currentColor"
                                        : "none"
                                    }
                                    className={
                                      star <= Number(review.rating)
                                        ? "text-[#A86643]"
                                        : "text-[#D4C6BA]"
                                    }
                                  />
                                ))}
                              </div>

                              {/* COMMENT */}

                              <p className="mt-4 text-sm leading-7 text-[#75675D]">
                                {review.comment}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* =====================================================
          RELATED PRODUCTS
      ====================================================== */}

      {relatedProducts.length > 0 && (
        <section className="bg-[#F7F1E8]">
          <div className="mx-auto max-w-7xl px-5 py-12 sm:px-6 lg:px-8 lg:py-16">
            <div className="mb-8 flex items-end justify-between gap-4">
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[#A86643]">
                  You may also like
                </p>

                <h2 className="mt-2 text-2xl font-bold text-[#4A3428] sm:text-3xl">
                  More from {product.category}
                </h2>
              </div>

              <Link
                to={`/${product.category.toLowerCase()}`}
                className="hidden items-center gap-1 text-sm font-semibold text-[#4A3428] transition hover:text-[#A86643] sm:flex"
              >
                View All
                <ArrowRight size={16} />
              </Link>
            </div>

            <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
              {relatedProducts.map((item) => (
                <ProductCard key={item.id} product={item} />
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

/* =========================================================
   PRODUCT TAB
========================================================= */

function ProductTab({ active, onClick, children }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex items-center whitespace-nowrap border-b-2 px-5 pb-4 text-sm font-semibold transition ${
        active
          ? "border-[#4A3428] text-[#4A3428]"
          : "border-transparent text-[#75675D] hover:text-[#A86643]"
      }`}
    >
      {children}
    </button>
  );
}

/* =========================================================
   TRUST FEATURE
========================================================= */

function TrustFeature({ icon: Icon, text }) {
  return (
    <div className="flex flex-col items-center rounded-xl bg-[#EFE3D4] px-2 py-4 text-center">
      <Icon size={20} className="text-[#A86643]" />

      <span className="mt-2 text-xs font-medium text-[#4A3428]">{text}</span>
    </div>
  );
}

export default ProductDetails;
